<?php
$host = "localhost";
$port = "3306";
$user = "r00t";
$pwd = "Fish_k0u_z0ne";
$dbname = "hctf_kouzone";
?>